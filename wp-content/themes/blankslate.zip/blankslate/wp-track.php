<?php


 $wpFbUserSection = get_currentuserinfo();
    $pageTitle = get_the_title();
if( is_user_logged_in()):
    
    
    if($wpFbUserSection->user_firstname == NULL ):
        $wpFbUserSection->user_firstname = $wpFbUserSection->user_nicename;
    endif;

//transforma string em letras minusculas
$wpFbUserSection->user_email = strtolower($wpFbUserSection->user_email);
$wpFbUserSection->user_firstname = strtolower($wpFbUserSection->user_firstname);
$wpFbUserSection->user_lastname = strtolower($wpFbUserSection->user_lastname);
else :
    //$usuarioPx = '"null"';

endif;



//RASTREAMENTO MAUTIC
$d = urlencode(base64_encode(serialize(array(
    'page_url'   => 'http://' . $_SERVER[HTTP_HOST] . $_SERVER['REQUEST_URI'],
    'page_title' => $pageTitle,    // Use your website's means of retrieving the title or manually insert it
    'email' => $wpFbUserSection->user_email // Use your website's means of user management to retrieve the email
))));

echo 'é ´ra ser o host http ou https = ' . $_SERVER[HTTP_HOST] . '<br/>';
echo 'é pra seo a url = ' . $_SERVER['REQUEST_URI'] . '<br/>';
echo 'é pra ser o título da pag= ' . get_the_title()  . '<br/>';
echo 'é pra ser o email = ' . $wpFbUserSection->user_email . '<br/>';
echo 'aqui é o codigo= ' . $d . '<br/>';


echo '<img src="http://your-mautic.com/mtracking.gif?d=' . $d . '" style="display: none;" />';

   ?>




<script>
    $(function (){
        FB_PIXEL_ID = '379326509076605';
        WP_USER = <?= json_encode($wpFbUserSection); ?>;
!function(f,b,e,v,n,t,s){
    if(f.fbq)
        return;
    n=f.fbq=function(){
        n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)
};
if(!f._fbq)
    f._fbq=n;
n.push=n;
n.loaded=!0;
n.version='2.0';
n.queue=[];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window,
                document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');

        //FB_RASRTREAMENTO
        if (WP_USER == null) {
            fbq('init', FB_PIXEL_ID);
        } else {
            fbq('init', FB_PIXEL_ID, {
                em: WP_USER.data.user_email, //e-mail user
                fn: WP_USER.data.user_firstname, //primeiro nome
                ln:WP_USER.data.user_lastname //ultimo nome
//                ph:'', //telefone quando for tratar isso pra lojas virtuais com woocommerce olhar a aula 
//                ge:'', //sexo f ou m
//                db:'', //data de nascimento
//                ct:'', //cidade
//                st:'', //estado
//                zp:'' //cep
            });
        }
//    console.log(WP_USER.data.user_email);
//    console.log(WP_USER.data.user_firstname);
//    console.log(WP_USER.data.user_lastname);
    
    //FB EVENTOS
    fbq('track', 'PageView');
    
        //RASTREAMENTO MAUTIC
//  mauticurl = "https://domumdei.mautic.net";
//src = mauticurl + '/mtracking.gif?page_url=' + encodeURIComponent(window.location.href) + '&page_title=' + encodeURIComponent(document.title) + '&email=' + WP_USER.data.user_email;
//img = document.createElement('img');
//img.style.width  = '1px';
//img.style.height  = '1px';
//img.style.display = 'none';
//img.src = src;
//img.email = WP_USER.data.user_email;
//body = document.getElementsByTagName('body')[0];
//body.appendChild(img);
// 
// console.log(mauticurl);
// console.log(src);
// console.log(img.style.width);
// console.log(img.src);
// console.log(img.email);
// console.log(body);
// console.log();
// console.log();
// console.log();
//FIM RASTREAMENTO MAUTIC
    });
    
    

    
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=379326509076605&ev=PageView&noscript=1"/></noscript>

<?php 

?>
